package br.com.unicuritiba.projectInvestimento.controler;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import br.com.unicuritiba.projectInvestimento.repositories.InvestimentoRepository;
import br.com.unicuritiba.projectinvestimento.models.Investimentos;


@RestController

public class InvestimentosControler {
	

	@Autowired
	InvestimentoRepository repository;
	
	
	
	@GetMapping("/investimentos")
	public ResponseEntity<List<Investimentos>> getInvestimentos(){
		return ResponseEntity.ok(repository.findAll());
	}
	
	@GetMapping("/investimentos/{id}")
	public ResponseEntity<Investimentos> getInvestimentos(@PathVariable long id){
		return ResponseEntity.ok(repository.findById(id).get());
	}
	
	@PostMapping("/investimentos")
	public ResponseEntity<Investimentos> saveInvestimento(
		@RequestBody Investimentos investimentos){
		Investimentos savedInvestimentos = repository.save(investimentos);
		return ResponseEntity.ok(savedInvestimentos);
	}

		
		@DeleteMapping("/investimentos/{id}")
		public void removeInvestimentos(@PathVariable long id) {
			repository.deleteById(id);
		}
		
		@PutMapping("/investimentos/{id}")
		public ResponseEntity<Investimentos> updateMovie(@PathVariable long id,
				@RequestBody Investimentos investimentos){
			investimentos.setId(id);
			Investimentos savedInvestimentos = repository.save(investimentos);
			return ResponseEntity.ok(savedInvestimentos);
		}
		
		

}
