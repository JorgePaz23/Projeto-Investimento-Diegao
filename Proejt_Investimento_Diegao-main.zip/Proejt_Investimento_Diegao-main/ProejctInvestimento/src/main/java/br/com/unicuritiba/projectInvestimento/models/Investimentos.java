package br.com.unicuritiba.projectInvestimento.models;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity

public class Investimentos {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	
	private long id;
	private String nomeInvestimento;
	private String periodoAplicado;
	private float rentabilidade;
	private float investimentoInicial;
	
	
	@ManyToOne
	private Cliente cliente;


	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	public String getNomeInvestimento() {
		return nomeInvestimento;
	}


	public void setNomeInvestimento(String nomeInvestimento) {
		this.nomeInvestimento = nomeInvestimento;
	}


	public String getPeriodoAplicado() {
		return periodoAplicado;
	}


	public void setPeriodoAplicado(String periodoAplicado) {
		this.periodoAplicado = periodoAplicado;
	}


	public float getRentabilidade() {
		return rentabilidade;
	}


	public void setRentabilidade(float rentabilidade) {
		this.rentabilidade = rentabilidade;
	}


	public float getInvestimentoInicial() {
		return investimentoInicial;
	}


	public void setInvestimentoInicial(float investimentoInicial) {
		this.investimentoInicial = investimentoInicial;
	}


	public Cliente getCliente() {
		return cliente;
	}


	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	
	


}
