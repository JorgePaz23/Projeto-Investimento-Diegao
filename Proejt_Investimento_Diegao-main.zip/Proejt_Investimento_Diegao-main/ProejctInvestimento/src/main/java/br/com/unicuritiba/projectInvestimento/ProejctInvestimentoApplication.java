package br.com.unicuritiba.projectInvestimento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProejctInvestimentoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProejctInvestimentoApplication.class, args);
	}

}
