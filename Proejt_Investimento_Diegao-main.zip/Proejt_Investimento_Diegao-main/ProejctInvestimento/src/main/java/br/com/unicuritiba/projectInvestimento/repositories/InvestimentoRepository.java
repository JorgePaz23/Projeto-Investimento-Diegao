package br.com.unicuritiba.projectInvestimento.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.unicuritiba.projectinvestimento.models.Investimentos;


public interface InvestimentoRepository  extends JpaRepository<Investimentos, Long> {

}
