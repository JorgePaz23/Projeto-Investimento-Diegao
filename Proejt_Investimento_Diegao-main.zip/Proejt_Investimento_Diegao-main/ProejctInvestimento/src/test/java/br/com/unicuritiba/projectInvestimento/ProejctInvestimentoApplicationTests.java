package br.com.unicuritiba.projectInvestimento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProejctInvestimentoApplicationTests {

	@Test
	void contextLoads() {
	}

}
